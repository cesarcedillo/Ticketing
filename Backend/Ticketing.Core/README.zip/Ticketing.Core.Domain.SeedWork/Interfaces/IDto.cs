﻿
namespace Ticketing.Core.Domain.SeedWork.Interfaces;
public interface IDto
{
}
